"""
features/feature_engineer.py
Calculates all H4 and M15 features with rolling-window normalisation
(500 bars) to prevent data leakage.  Blueprint v2.0 Section 6.
"""

from typing import Optional
import numpy as np
import pandas as pd

from config.settings import (
    NORMALIZATION_WINDOW,
    ATR_PERIOD, RSI_PERIOD, EMA_FAST, EMA_SLOW,
    MACD_FAST, MACD_SLOW, MACD_SIGNAL,
    STOCH_K, STOCH_D,
    LONDON_SESSION_START_UTC, LONDON_SESSION_END_UTC,
    NY_SESSION_START_UTC, NY_SESSION_END_UTC,
)
from utils.logger import setup_logger

log = setup_logger("FeatureEngineer")


# ─────────────────────────────────────────────────────────────────────────────
# Low-level indicator helpers (no external ta library dependency at runtime)
# ─────────────────────────────────────────────────────────────────────────────

def _ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain  = delta.clip(lower=0)
    loss  = (-delta).clip(lower=0)
    avg_gain = gain.ewm(com=period - 1, adjust=False).mean()
    avg_loss = loss.ewm(com=period - 1, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def _atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low  - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(com=period - 1, adjust=False).mean()


def _macd(close: pd.Series, fast: int, slow: int, signal: int):
    ema_fast   = _ema(close, fast)
    ema_slow   = _ema(close, slow)
    macd_line  = ema_fast - ema_slow
    signal_line = _ema(macd_line, signal)
    histogram  = macd_line - signal_line
    return macd_line, signal_line, histogram


def _stochastic(high: pd.Series, low: pd.Series, close: pd.Series,
                k: int = 14, d: int = 3):
    lowest_low   = low.rolling(k).min()
    highest_high = high.rolling(k).max()
    stoch_k = 100 * (close - lowest_low) / (highest_high - lowest_low).replace(0, np.nan)
    stoch_d = stoch_k.rolling(d).mean()
    return stoch_k, stoch_d


def _rolling_zscore(series: pd.Series, window: int) -> pd.Series:
    """Rolling z-score normalisation using only past N bars (no leakage)."""
    mu  = series.rolling(window, min_periods=max(window // 4, 10)).mean()
    std = series.rolling(window, min_periods=max(window // 4, 10)).std()
    return (series - mu) / std.replace(0, np.nan)


def _slope(series: pd.Series, lookback: int = 5) -> pd.Series:
    """Approximate slope via linear regression over last `lookback` bars."""
    def _ls(arr):
        if np.isnan(arr).any():
            return np.nan
        x = np.arange(len(arr))
        return np.polyfit(x, arr, 1)[0]
    return series.rolling(lookback).apply(_ls, raw=True)


# ─────────────────────────────────────────────────────────────────────────────
# Higher-High / Lower-Low detection
# ─────────────────────────────────────────────────────────────────────────────

def _hh_ll(high: pd.Series, low: pd.Series, lookback: int = 20) -> pd.DataFrame:
    rolling_high = high.rolling(lookback).max()
    rolling_low  = low.rolling(lookback).min()
    hh = (high == rolling_high).astype(float)
    ll = (low  == rolling_low).astype(float)
    return pd.DataFrame({"higher_high": hh, "lower_low": ll})


# ─────────────────────────────────────────────────────────────────────────────
# Main Feature Engineering Class
# ─────────────────────────────────────────────────────────────────────────────

class FeatureEngineer:
    """
    Computes normalised feature vectors for H4 (trend context) and
    M15 (entry timing).  All normalisations use a 500-bar rolling window.
    """

    def __init__(self, norm_window: int = NORMALIZATION_WINDOW):
        self.norm_window = norm_window

    # ── H4 Features ───────────────────────────────────────────────────────────

    def compute_h4_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Input:  H4 OHLCV DataFrame with datetime index
        Output: DataFrame of normalised H4 features (same index)
        """
        close = df["close"]
        high  = df["high"]
        low   = df["low"]

        feat = pd.DataFrame(index=df.index)

        # ── Trend Strength ────────────────────────────────────────────────────
        ema50  = _ema(close, EMA_FAST)
        ema200 = _ema(close, EMA_SLOW)
        feat["dist_ema50"]  = (close - ema50)  / close          # % distance
        feat["dist_ema200"] = (close - ema200) / close
        feat["ema_cross"]   = (ema50 - ema200) / close          # sign = trend direction

        # ── Momentum ─────────────────────────────────────────────────────────
        feat["rsi14"] = _rsi(close, RSI_PERIOD) / 100.0         # normalise to [0,1]
        _, _, macd_hist = _macd(close, MACD_FAST, MACD_SLOW, MACD_SIGNAL)
        feat["macd_hist"] = macd_hist / close

        # ── Volatility ────────────────────────────────────────────────────────
        atr14 = _atr(high, low, close, ATR_PERIOD)
        feat["atr14_pct"] = atr14 / close                       # ATR as % of price

        # ── Trend Slope ───────────────────────────────────────────────────────
        feat["ema50_slope"]  = _slope(ema50, lookback=5)  / close
        feat["ema200_slope"] = _slope(ema200, lookback=5) / close

        # ── Market Structure ─────────────────────────────────────────────────
        hh_ll = _hh_ll(high, low, lookback=20)
        feat["higher_high"] = hh_ll["higher_high"]
        feat["lower_low"]   = hh_ll["lower_low"]

        # ── Price momentum returns ────────────────────────────────────────────
        for p in [1, 3, 5, 10]:
            feat[f"ret_{p}b"] = close.pct_change(p)

        # ── Rolling z-score normalisation ─────────────────────────────────────
        skip_norm = {"higher_high", "lower_low", "rsi14"}  # already in [0,1] or binary
        for col in feat.columns:
            if col not in skip_norm:
                feat[col] = _rolling_zscore(feat[col], self.norm_window)

        feat = feat.replace([np.inf, -np.inf], np.nan)
        return feat

    # ── M15 Features ──────────────────────────────────────────────────────────

    def compute_m15_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Input:  M15 OHLCV DataFrame with datetime index
        Output: DataFrame of normalised M15 features (same index)
        """
        close  = df["close"]
        high   = df["high"]
        low    = df["low"]
        open_  = df["open"]
        volume = df["volume"]
        spread = df["spread"]

        feat = pd.DataFrame(index=df.index)

        # ── Momentum ─────────────────────────────────────────────────────────
        feat["rsi14"] = _rsi(close, RSI_PERIOD) / 100.0
        stoch_k, stoch_d = _stochastic(high, low, close, STOCH_K, STOCH_D)
        feat["stoch_k"] = stoch_k / 100.0
        feat["stoch_d"] = stoch_d / 100.0

        # ── Volatility ────────────────────────────────────────────────────────
        atr14 = _atr(high, low, close, ATR_PERIOD)
        feat["atr14_pct"] = atr14 / close

        # Volatility expansion: ratio of current ATR vs rolling average
        atr_avg = atr14.rolling(50).mean()
        feat["vol_expansion"] = atr14 / atr_avg.replace(0, np.nan)

        # Candle range as % of ATR
        feat["candle_range_pct"] = (high - low) / atr14.replace(0, np.nan)

        # ── Price Position ────────────────────────────────────────────────────
        # VWAP (session-level approximation using rolling 96-bar window = 1 day M15)
        typical = (high + low + close) / 3
        vwap_vol = (typical * volume).rolling(96).sum()
        vol_sum  = volume.rolling(96).sum().replace(0, np.nan)
        vwap     = vwap_vol / vol_sum
        feat["dist_vwap"] = (close - vwap) / close

        ema20 = _ema(close, 20)
        ema50 = _ema(close, EMA_FAST)
        feat["dist_ema20"] = (close - ema20) / close
        feat["dist_ema50"] = (close - ema50) / close

        # ── Breakout indicators ───────────────────────────────────────────────
        for lb in [12, 24, 48]:   # 3h, 6h, 12h
            rolling_high = high.rolling(lb).max().shift(1)
            rolling_low  = low.rolling(lb).min().shift(1)
            feat[f"break_high_{lb}b"] = ((close > rolling_high) & (close.shift(1) <= rolling_high)).astype(float)
            feat[f"break_low_{lb}b"]  = ((close < rolling_low)  & (close.shift(1) >= rolling_low)).astype(float)

        # ── Liquidity / spread ────────────────────────────────────────────────
        feat["spread_pips"] = spread  # raw spread kept unnormalised for filter use

        # ── Session flags ─────────────────────────────────────────────────────
        hour = df.index.hour
        feat["london_session"] = ((hour >= LONDON_SESSION_START_UTC) &
                                   (hour <  LONDON_SESSION_END_UTC)).astype(float)
        feat["ny_session"]     = ((hour >= NY_SESSION_START_UTC) &
                                   (hour <  NY_SESSION_END_UTC)).astype(float)

        # ── Price momentum returns ────────────────────────────────────────────
        for p in [1, 3, 8, 16]:
            feat[f"ret_{p}b"] = close.pct_change(p)

        # Body ratio (close vs open)
        feat["body_ratio"] = (close - open_) / (high - low).replace(0, np.nan)

        # ── Rolling z-score normalisation ─────────────────────────────────────
        skip_norm = {
            "rsi14", "stoch_k", "stoch_d",
            "london_session", "ny_session",
            "spread_pips",
            *[c for c in feat.columns if c.startswith("break_")]
        }
        for col in feat.columns:
            if col not in skip_norm:
                feat[col] = _rolling_zscore(feat[col], self.norm_window)

        feat = feat.replace([np.inf, -np.inf], np.nan)
        return feat

    # ── Merge H4 context into M15 ─────────────────────────────────────────────

    @staticmethod
    def merge_h4_context_into_m15(m15: pd.DataFrame,
                                   h4_features: pd.DataFrame,
                                   prefix: str = "h4_ctx_") -> pd.DataFrame:
        """
        Forward-merge H4 features into each M15 bar using last-known H4 value.
        Avoids look-ahead bias by using merge_asof with direction='backward'.
        """
        h4_prefixed = h4_features.copy()
        h4_prefixed.columns = [prefix + c for c in h4_features.columns]
        h4_prefixed = h4_prefixed.reset_index().rename(columns={"datetime": "datetime"})
        if "datetime" not in h4_prefixed.columns:
            h4_prefixed = h4_prefixed.rename(columns={h4_prefixed.columns[0]: "datetime"})

        m15_reset = m15.reset_index()
        m15_col   = m15_reset.columns[0]  # datetime column name

        merged = pd.merge_asof(
            m15_reset.sort_values(m15_col),
            h4_prefixed.sort_values("datetime"),
            left_on=m15_col,
            right_on="datetime",
            direction="backward",
        )
        merged = merged.drop(columns=["datetime"], errors="ignore")
        merged = merged.set_index(m15_col)
        return merged
